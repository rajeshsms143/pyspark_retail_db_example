def src_file(path,file_name,format):
    final_src_file = f'file:{path}/{file_name}.{format}'
    return final_src_file

